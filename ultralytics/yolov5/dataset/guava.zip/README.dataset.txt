# guava > 2025-03-26 6:44pm
https://universe.roboflow.com/grid-air2x/guava-gvhzp

Provided by a Roboflow user
License: Public Domain

