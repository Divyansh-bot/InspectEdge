# fresh_orange > 2025-03-26 7:57pm
https://universe.roboflow.com/albert-vfswp/fresh_orange-bisbo

Provided by a Roboflow user
License: Public Domain

