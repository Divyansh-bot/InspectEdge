# Grapes > 2025-03-26 5:54pm
https://universe.roboflow.com/grid-air2x/grapes-mrlti

Provided by a Roboflow user
License: Public Domain

