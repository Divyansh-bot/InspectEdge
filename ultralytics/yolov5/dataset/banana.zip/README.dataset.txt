# Banana > 2025-03-26 9:48pm
https://universe.roboflow.com/albert-vfswp/banana-qzn7z

Provided by a Roboflow user
License: Public Domain

