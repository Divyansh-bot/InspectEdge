# rotten_orange > 2025-03-26 7:48pm
https://universe.roboflow.com/albert-vfswp/rotten_orange-u5hqx

Provided by a Roboflow user
License: Public Domain

